

## v4 additions
- Unlock screen (password) + in-memory key holder.
- Backups saved encrypted by default when unlocked; can restore encrypted or plain ZIP.
- Attachment storage layer encrypts data transparently when unlocked.
- Rich text block shows bullets/numbering and checklist prefixes; tap chips to toggle.


## CI builds (APK without a laptop)
- Push this repo to GitHub.
- Add secrets for signing (optional).
- Actions will produce a Debug APK and, if secrets exist, a signed Release APK.
See `scripts/keystore_instructions.md`.
