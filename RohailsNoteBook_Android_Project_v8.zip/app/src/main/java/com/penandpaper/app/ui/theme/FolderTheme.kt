
package com.penandpaper.app.ui.theme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.TopAppBarColors
import androidx.compose.material3.MaterialTheme
import androidx.compose.ui.graphics.luminance

object FolderTheme {
    var color: Color? by mutableStateOf(null)
    var contentMode: String by mutableStateOf("auto") // auto | light | dark | themeOnPrimary | themeOnSurface
    var preferLight: Boolean by mutableStateOf(false)
    var useAccentForHighlights: Boolean by mutableStateOf(true)

    fun appBarColors(): TopAppBarColors {
        val container = color ?: TopAppBarDefaults.topAppBarColors().containerColor(true).value
        val content = when (contentMode) {
            "light" -> Color.White
            "dark" -> Color.Black
            "themeOnPrimary" -> MaterialTheme.colorScheme.onPrimary
            "themeOnSurface" -> MaterialTheme.colorScheme.onSurface
            else -> {
                val auto = if (container.luminance() < 0.5f) Color.White else Color.Black
                if (preferLight) Color.White else auto
            
    fun accentColor(default: androidx.compose.ui.graphics.Color): androidx.compose.ui.graphics.Color {
        return color?.copy(alpha = 0.85f) ?: default
    }
}
        
    fun accentColor(default: androidx.compose.ui.graphics.Color): androidx.compose.ui.graphics.Color {
        return color?.copy(alpha = 0.85f) ?: default
    }
}
        return TopAppBarDefaults.topAppBarColors(
            containerColor = container,
            titleContentColor = content,
            navigationIconContentColor = content,
            actionIconContentColor = content
        )
    
    fun accentColor(default: androidx.compose.ui.graphics.Color): androidx.compose.ui.graphics.Color {
        return color?.copy(alpha = 0.85f) ?: default
    }
}

    fun accentColor(default: androidx.compose.ui.graphics.Color): androidx.compose.ui.graphics.Color {
        return color?.copy(alpha = 0.85f) ?: default
    }
}
