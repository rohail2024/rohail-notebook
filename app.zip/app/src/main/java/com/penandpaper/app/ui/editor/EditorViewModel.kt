
package com.penandpaper.app.ui.editor
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.penandpaper.domain.model.Note
import com.penandpaper.domain.model.NoteBlock
import com.penandpaper.domain.model.BlockType
import com.penandpaper.domain.repo.NotesRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import org.json.JSONObject
import javax.inject.Inject

@HiltViewModel
class EditorViewModel @Inject constructor(
    private val repo: NotesRepository
) : ViewModel() {
    private val _title = MutableStateFlow("")
    val title: StateFlow<String> = _title
    private val _blocks = MutableStateFlow<List<NoteBlock>>(emptyList())
    val blocks: StateFlow<List<NoteBlock>> = _blocks
    var noteId: Long = 0L
        private set
    fun load(noteId: Long) {
        this.noteId = noteId
        viewModelScope.launch {
            if (noteId == 0L) {
                val now = System.currentTimeMillis()
                this@EditorViewModel.noteId = repo.upsertNote(Note(0, "Untitled", now, now, false, false, null))
            } else {
                // TODO: load existing blocks from DB and set _blocks
            }
        }
    }
    fun setTitle(t: String) { _title.value = t }
    fun addTextBlock() {
        viewModelScope.launch {
            val meta = JSONObject().apply {
                put("content", "")
                put("style", JSONObject().apply {
                    put("fontFamily","Sans"); put("fontSize",16); put("bold",false); put("italic",false); put("underline",false)
                })
            }.toString()
            val newBlock = NoteBlock(0, noteId, BlockType.TEXT, _blocks.value.size, null, meta)
            val id = repo.addBlock(newBlock)
            _blocks.value = _blocks.value + newBlock.copy(id = id)
        }
    }
    fun getBlockMeta(index: Int): String = _blocks.value.getOrNull(index)?.metaJson ?: "{}"
    fun setBlockMeta(index: Int, meta: String) {
        val list = _blocks.value.toMutableList()
        list[index] = list[index].copy(metaJson = meta)
        _blocks.value = list
    }
    fun getBlockStyle(index: Int): BlockStyle {
        val obj = _blocks.value.getOrNull(index)?.metaJson?.let { JSONObject(it).optJSONObject("style") }
        return BlockStyle(
            fontFamily = obj?.optString("fontFamily","Sans") ?: "Sans",
            fontSize = obj?.optInt("fontSize",16) ?: 16,
            bold = obj?.optBoolean("bold", false) ?: false,
            italic = obj?.optBoolean("italic", false) ?: false,
            underline = obj?.optBoolean("underline", false) ?: false
        )
    }
    fun setBlockStyle(index: Int, st: BlockStyle) {
        val list = _blocks.value.toMutableList()
        val obj = JSONObject(list[index].metaJson ?: "{}")
        val s = (obj.optJSONObject("style") ?: JSONObject())
        s.put("fontFamily", st.fontFamily)
        s.put("fontSize", st.fontSize)
        s.put("bold", st.bold)
        s.put("italic", st.italic)
        s.put("underline", st.underline)
        obj.put("style", s)
        list[index] = list[index].copy(metaJson = obj.toString())
        _blocks.value = list
    }
    suspend fun persistDraft() {
        val now = System.currentTimeMillis()
        repo.upsertNote(Note(noteId, _title.value.ifEmpty { "Untitled" }, now, now, false, false, null))
        _blocks.value.forEach { repo.updateBlock(it) }
    }
}
