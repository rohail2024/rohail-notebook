
package com.penandpaper.app.ui.editor
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Checkbox
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.penandpaper.app.richtext.*

@Composable
fun RichTextBlock(meta: String?, onChange: (String) -> Unit) {
    var doc by remember(meta) { mutableStateOf(richFromJson(meta)) }
    OutlinedCard {
        // simple toolbar toggles paragraph-level checklist and run style (whole paragraph)
        var checklist by remember { mutableStateOf(false) }
        var bold by remember { mutableStateOf(false) }
        var italic by remember { mutableStateOf(false) }
        var underline by remember { mutableStateOf(false) }
        Column(Modifier.padding(12.dp)) {
            FilterChip(checklist, onClick = { checklist = !checklist; doc = doc.copy(paragraphs = doc.paragraphs.map { it.copy(checklist = checklist) }); onChange(doc.toJson()) }, label = { Text("Checklist") })
            FilterChip(bold, onClick = { bold = !bold; doc = doc.copy(paragraphs = doc.paragraphs.map { it.copy(runs = it.runs.map { r -> r.copy(bold = bold) })) }); onChange(doc.toJson()) }, label = { Text("B") })
            FilterChip(italic, onClick = { italic = !italic; doc = doc.copy(paragraphs = doc.paragraphs.map { it.copy(runs = it.runs.map { r -> r.copy(italic = italic) })) }); onChange(doc.toJson()) }, label = { Text("I") })
            FilterChip(underline, onClick = { underline = !underline; doc = doc.copy(paragraphs = doc.paragraphs.map { it.copy(runs = it.runs.map { r -> r.copy(underline = underline) })) }); onChange(doc.toJson()) }, label = { Text("U") })
            val styled = buildAnnotatedString {
                doc.paragraphs.forEachIndexed { idx, p ->
                    p.runs.forEach { r ->
                        pushStyle(SpanStyle(
                            fontFamily = FontFamily.SansSerif,
                            fontSize = 16.sp,
                            fontWeight = if (r.bold) FontWeight.Bold else FontWeight.Normal,
                            fontStyle = if (r.italic) FontStyle.Italic else FontStyle.Normal,
                            textDecoration = if (r.underline) TextDecoration.Underline else TextDecoration.None
                        ))
                        append(r.text)
                        pop()
                    }
                    if (idx < doc.paragraphs.lastIndex) append("\n")
                }
            }
            Text(styled, modifier = Modifier.padding(top = 8.dp))
        }
    }
}
